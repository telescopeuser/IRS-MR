Note that this file is copyright the Jboss Drools project and is released under the Apache 2 Licence
The Original is available from http://anonsvn.labs.jboss.com/labs/jbossrules/soa_tags/4.3.0.GA_IR1/drools-examples/drools-insurance

